import DonationGraph from '@/components/DonationGraph'
import React from 'react'

const Pool = () => {
  return (
    <div className='max-w-screen-xl ml-10 '>
        <DonationGraph/>
        Pool</div>
  )
}

export default Pool